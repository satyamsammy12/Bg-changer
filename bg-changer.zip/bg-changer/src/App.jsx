import React, { useState } from "react";

const App = () => {
  const [color, setColor] = useState("black");

  return (
    <div>
      <div
        className="w-full h-screen duration-200"
        style={{ backgroundColor: color }}
      >
        <div className="fixed bottom-12 left-0 right-0 px-2 flex justify-center">
          <div className="flex flex-wrap justify-center gap-3 shadow-black shadow-inner shadow-sm bg-white px-3 py-2 rounded-3xl ">
            <button
              onClick={() => setColor("red")}
              className="outline-none px-4 py-1 rounded-full text-white"
              style={{ backgroundColor: "red" }}
            >
              {" "}
              Red
            </button>
            <button
              onClick={() => setColor("blue")}
              className="outline-none px-4 py-1 rounded-full text-white"
              style={{backgroundColor: "blue"}}
            >
              {" "}
              Blue
            </button>
            <button
              onClick={() => setColor("green")}
              className="outline-none px-4 py-1 rounded-full text-white"
              style={{ backgroundColor: "green" }}
            >
              {" "}
              Green
            </button>
            <button
              onClick={() => setColor("olive")}
              className="outline-none px-4 py-1 rounded-full text-white"
              style={{ backgroundColor: "olive" }}
            >
              {" "}
              Olive
            </button>
            <button
              onClick={() => setColor("black")}
              className="outline-none px-4 py-1 rounded-full text-white"
              style={{ backgroundColor: "Black" }}
            >
              {" "}
              Black
            </button>
            <button
              onClick={() => setColor("white")}
              className="outline-none px-4 py-1 rounded-full text-black"
              style={{ backgroundColor: "White" }}
            >
              {" "}
              White
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
